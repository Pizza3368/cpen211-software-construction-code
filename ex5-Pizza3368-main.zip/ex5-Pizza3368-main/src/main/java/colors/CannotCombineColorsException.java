package colors;

public class CannotCombineColorsException extends RuntimeException {
    public CannotCombineColorsException(String msg) {
        super(msg);
    }
}

package colors;

import java.util.ArrayList;
import java.util.HashSet;
import java.util.List;
import java.util.Set;

public class ColorMixer {

    /**
     * Given a list of colors, combine all colors to form a new color.
     * Recall that colors can be combined if their component-wise sum is divisible by
     * the number of colors being combined.
     * @param colors A list of color objects.
     * @return The result of the color combination as a Color object
     * @throws CannotCombineColorsException if the colors cannot be combined
     */
    public Color combine(List<Color> colors) throws CannotCombineColorsException {
        // TODO: Implement this
        //find find red green blue total
        int redSum = 0;
        int greenSum = 0;
        int blueSum = 0;

        for(Color cr: colors){
            redSum = cr.red+redSum;
            greenSum = cr.green+greenSum;
            blueSum = cr.blue+blueSum;
        }

        if(redSum % colors.size()!=0 || greenSum%colors.size()!=0||blueSum%colors.size()!=0){
            throw new CannotCombineColorsException("the rgb can not be perfectly divided");
        }

        Color temp = new Color(redSum/ colors.size(),greenSum/ colors.size(),blueSum/ colors.size());




        return temp;
    }

    /**
     * Given a list of colors and a target color, determine if there is some combination of
     * colors that can be combined to get a target color.
     * @param colors a list of colors.
     * @param target a target color.
     * @return True if there is some combination of colors that can be combined to get target. False otherwise.
     */
    public boolean createColor(List<Color> colors, Color target){
        // TODO: Implement this
        Set<List<Color>> oc = new HashSet<>();
        oc = badStyle(colors);

        for(List<Color> c : oc){
            int rs =0;
            int gs =0;
            int bs=0;

            for(Color sc: c){
                rs = rs+sc.red;
                gs = gs+sc.green;
                bs = bs+sc.blue;

            }

            if(target.red*c.size()==rs&&target.green*c.size()==gs&&target.blue*c.size()==bs){
                return true;
            }

        }






        return false;
    }

    private Set<List<Color>> badStyle(List<Color> colors){
        Set<List<Color>> temp = new HashSet<>();

        if(colors.size() == 1){
            temp.add(colors);
            return temp;
        }

        temp.add(colors);
        for(Color c: colors){

            List<Color> nt = new ArrayList<>(colors);
            nt.remove(c);
            Set<List<Color>> ss = new HashSet<>();
            ss = badStyle(nt);
            temp.addAll(ss);
        }

        return temp;
    }


}

package colors;

import java.util.ArrayList;
import java.util.List;
import java.util.Objects;

public class Color {


    Integer red;
    Integer green;
    Integer blue;

    /**
     * First constructor for color
     * @param color of the form '#uvwxyz'
     */
    public Color(String color){
        // TODO: Implement this
        String red = color.substring(1,3);
        String green = color.substring(3,5);
        String blue = color.substring(5);
        this.red = (Integer.parseInt(red, 16));
        this.green = (Integer.parseInt(green, 16));
        this.blue = (Integer.parseInt(blue, 16));

    }

    /**
     * Second constructor for color
     * @param red the units of red (0 <= red <= 255>
     * @param green the units of green (0 <= green <= 255)
     * @param blue the units of blue (0 <= blue <= 255)
     */
    public Color(int red, int green, int blue){
        // TODO: Implement this
        this.red = red;
        this.green = green;
        this.blue = blue;
    }

    /**
     * Create a list of components for the current color.
     * @return A list of integers L where L[0], L[1] and L[2] are the red, green and blue
     * components of the color respectively.
     */
    public List<Integer> components(){
        // TODO: Implement this
        List<Integer> temp = new ArrayList<Integer>();
        temp.add(this.red);
        temp.add(this.green);
        temp.add(this.blue);
        return temp;
    }

    @Override
    public boolean equals(Object o) {
        if (this == o) return true;
        if (o == null || getClass() != o.getClass()) return false;
        Color color = (Color) o;
        return red.equals(color.red) && green.equals(color.green) && blue.equals(color.blue);
    }



    @Override
    public int hashCode() {
        return Objects.hash(red, green, blue);
    }
}
